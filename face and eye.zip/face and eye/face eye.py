import cv2
import os
FACE = cv2.CascadeClassifier("%s//face.xml" %os.path.dirname(__file__))
EYE  = cv2.CascadeClassifier("%s//eye.xml"  %os.path.dirname(__file__))
cap = cv2.VideoCapture(0)
while(True):
    key = cv2.waitKey(1)
    ret,frame = cap.read()
    face = FACE.detectMultiScale(frame)
    face_img = []
    for x, y, w, h in face:
        face_img += [[x, y, frame[y : y + h, x : x + w], w, h]]
    roop_time = 0
    for img in face_img:
        eye = EYE.detectMultiScale(img[2])
        if 2 <= len(eye):
            cv2.rectangle(frame, (img[0], img[1]), (img[0] + img[3], img[1] + img[4]), (0, 0, 255), 5)
            for x, y, w, h in eye:
                cv2.rectangle(frame, (img[0] + x, img[1] + y), (img[0] + x + w, img[1] + y + h), (255, 0, 0), 5)
        roop_time += 1
    cv2.imshow("img", frame)